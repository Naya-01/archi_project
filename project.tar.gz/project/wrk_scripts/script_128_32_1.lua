wrk.method = "POST"
wrk.headers["Content-Type"] = "application/x-www-form-urlencoded"
wrk.body = "128,32,1,nHXmwOdW5JUWn9Z7LxrhXHFC1wJQEU7scVVOkykg853l5SiGFQodXufOgpfk9dSbyoqZdQ6bMzCHHlNN12qPmMeI29t1cBTRq9rJQnkccnkkPyyHqfWSr0ajzJbSLvk2vRBC4lfXPF7e3wlkR829yTiodA7pwhhh"
